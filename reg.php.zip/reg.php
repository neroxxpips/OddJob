

<!DOCTYPE html>
<html>
<head>
	<title>Voter Registration</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body class="">
	
<div class="main1" id="tel1">
	<form action="connect.php" method="post">
		<div class="container">

			<div class="row">
				<div class="col-sm-4">
					<h1 align="center"><b>Voter Registration</b></h1>
					<p>Fill up the form with correct values.</p>
					<hr class="mb-4">
					<!-- <label for="image"><b>Image</b></label>
					<input class="form-control" type="text" name="image" required> 
 -->
					<label for="image"><b>Image</b></label>
					<input class="form-control" type="file" name="image" required>
					

					<label for="firstname"><b>First Name</b></label>
					<input class="form-control" type="text" name="firstname" required>

					<label for="lastname"><b>Last Name</b></label>
					<input class="form-control" type="text" name="lastname" required>

				
 					<label for="sex"><b>Sex</b></label>
					<select type="text" for="sex" name="sex" class="form-control">
					  <option selected>Choose One</option>
					  <option>male</option>
					  <option>female</option>
					</select>

					<label for="username"><b>Username</b></label>
					<input class="form-control" type="text" name="username" required>

					<label for="password"><b>Password</b></label>
					<input class="form-control" type="password" name="password" id="pwd" required>

					<label for="course"><b>Course</b></label>
					<input class="form-control type="text" name="course" required>

					<label for="sponsor"><b>Sponsor</b></label>
					<input class="form-control" type="text" name="sponsor" required>
					<hr class="mb-3">
					
					<input class="btn btn-primary" type="submit" name="submit" value="Register">
				</div>	
				<div class="col-sm-4">
				</div>
				<div class="col-sm-4"  id="took">
				<p style="margin-top: 50px">Already Registered? Click to Sign In</p>
				<hr class="mb-4" >
				<h1><b><a href="login.php">Sign in</a></b></h1>
				<hr class="mb-4">
				
				</div>
			</div>	
		</div>
		
	</form>
</div>
</body>
</html>